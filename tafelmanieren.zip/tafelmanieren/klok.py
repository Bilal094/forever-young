for i in range(00,13,+1):
    print(i,'AM')
for e in range(13,23+1):
    print(e,'PM')
input('')