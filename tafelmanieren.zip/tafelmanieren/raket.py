print('Raket lanceert over...')
from time import sleep
sleep(1.5)
for i in range(30,-1,-1):
    from time import sleep
    sleep(1)
    print(i)

print('*Raket vliegt de lucht in*')

input('')