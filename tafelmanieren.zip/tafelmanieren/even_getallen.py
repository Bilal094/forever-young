for e in range(20,51,+2):
    print(e)
input('')