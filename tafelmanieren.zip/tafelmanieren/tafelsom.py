cijfer = int(input('Type een cijfer in '))

for i in range(1,11):
    print(i * cijfer)

input('')